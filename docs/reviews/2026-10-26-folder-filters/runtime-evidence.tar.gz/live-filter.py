from manual import *
L=C/'live'
for side in ['left','right']:
 p=L/side;p.mkdir(parents=True,exist_ok=True);(p/'keep.txt').write_text('same\n');(p/'existing.bin').write_text(side+' existing\n')
with manual():
 compare(L/'left',L/'right');pattern('*.txt');time.sleep(.3);snapshot('50-live-filter-before');summary('live-before')
 (L/'left/existing.bin').write_text('EXTERNAL changed binary\n');(L/'left/new.bin').write_text('NEW hidden binary\n');time.sleep(1.1);summary('live-after-hidden-writes');snapshot('51-live-filter-leaked-files')
 click('⟳ Refresh');settled();time.sleep(.15);summary('live-after-full-refresh');snapshot('52-live-filter-refresh-restores')
 (L/'left/keep.txt').unlink();(L/'right/keep.txt').unlink();time.sleep(.9);summary('live-after-visible-delete');snapshot('53-live-filter-after-delete');close_active()
