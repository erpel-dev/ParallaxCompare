from manual import *
with manual():
 compare(C/'left',C/'right')
 for p in ['?.txt','??.txt','???.txt','????.txt','ä.txt','Ä.txt','*.{java,kt}']:
  st=pattern(p);event('unicode-brace-confirm',{'input':p,**st})
  if p in ['?.txt','??.txt','????.txt']:snapshot('40-unicode-'+str(len(p.split('.')[0])))
 pattern('*.java *.kt');summary('brace-workaround');snapshot('41-brace-workaround');pattern('*.txt');keys('\ue00c');time.sleep(.2);summary('escape-cleared');snapshot('42-escape-cleared');close_active()
