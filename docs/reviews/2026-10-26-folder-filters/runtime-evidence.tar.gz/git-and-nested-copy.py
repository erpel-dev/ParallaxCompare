from manual import *
import zipfile
for side in ['left','right']:
 p=C/'nested-copy'/side/'wrapper'/'bundle.zip';p.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(p,'w')as z:z.writestr('keep.txt',side+' keep\n');z.writestr('hidden.bin',side+' PROTECTED\n')
 (p.parent/'normal.txt').write_text(side+' normal\n')
with manual():
 repo=str(C/'git');compare(repo+'@base',repo+'@same');pattern('missing*.txt');summary('git-no-matches');snapshot('20-git-filter-no-matches');click('Expand');time.sleep(.2);summary('git-no-matches-expanded');snapshot('21-git-filter-expanded');click('Flat');time.sleep(.2);summary('git-no-matches-flat');close_active()
 compare(C/'nested-copy/left',C/'nested-copy/right');pattern('*.txt');summary('nested-copy-before');snapshot('22-nested-archive-before');js('const r=[...document.querySelectorAll(".page:not([hidden]) .viewport .row")].find(e=>e.querySelector(".name")?.innerText.includes("wrapper"));r.click()');click('Copy →');time.sleep(.2);desktop_key('Return');time.sleep(.4)
 with zipfile.ZipFile(C/'nested-copy/right/wrapper/bundle.zip')as z:event('nested-filtered-copy',{'archive':{n:z.read(n).decode()for n in z.namelist()},'normal':(C/'nested-copy/right/wrapper/normal.txt').read_text()})
 snapshot('23-nested-archive-after');summary('nested-copy-after');close_active()
