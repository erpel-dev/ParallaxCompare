from manual import *
with manual():
 compare(C/'large/left',C/'large/right');settled();snapshot('30-large-baseline');results=[]
 for p in ['*.txt','file0001.txt','sub00/*.txt','sub00/**/*.txt','*000?.txt','missing*','*.txt']:
  t=time.monotonic();st=pattern(p);results.append({'pattern':p,'seconds':time.monotonic()-t,'status':st['status'],'filters':st['filters'],'error':st['error']})
 event('large-pattern-performance',results)
 for i in range(20):
  js('const e=document.querySelector(".page:not([hidden]) .patterns input");e.focus();for(const p of ["*.txt","file0001.txt","missing*"]){e.value=p;e.dispatchEvent(new Event("input",{bubbles:true}));e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:true,cancelable:true}));}');time.sleep(.25);settled();st=state();event('rapid-pattern-final',{'iteration':i,'state':st});check('latest-rapid-filter-wins','Showing 0 of 0'in(st['status']or'')and not st['rows'],st)
 snapshot('31-large-rapid-final');pattern('*.txt');click('Flat');time.sleep(.2);summary('large-flat');snapshot('32-large-flat');close_active()
