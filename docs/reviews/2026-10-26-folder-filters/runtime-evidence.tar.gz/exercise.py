from filter_ui import *
import runpy,traceback,fcntl
start=json.loads((ROOT/'started.json').read_text())['monotonic'];end=start+900
with (ROOT/'gui.lock').open('w')as l:
 fcntl.flock(l,fcntl.LOCK_EX);runpy.run_path(str(ROOT/'initial-round.py'))
i=0;errors=[]
while time.monotonic()<end:
 if(ROOT/'pause').exists():time.sleep(.2);continue
 with(ROOT/'gui.lock').open('w')as l:
  fcntl.flock(l,fcntl.LOCK_EX)
  if(ROOT/'pause').exists():continue
  i+=1
  try:
   compare(C/'left',C/'right');settled()
   p=['*.txt','src/**/*.rs','*.java *.kt','file[12].log','missing*'][i%5];t=time.monotonic();st=pattern(p)
   if i%3==0:click('Flat');time.sleep(.1)
   for label in ['All differences','Same','All files']:click(label,prefix=True)
   # The GUI-only brace parsing defect must not affect plain alternation.
   if p=='*.java *.kt':check('plain-alternatives-present',any('java'in x['left']or'kt'in x['left']for x in st['rows']))
   check('filter-no-error',not st['error'],p)
   if i%15==0:snapshot(f'80-cycle-{i:03}')
   close_active();event('filter-cycle',{'cycle':i,'pattern':p,'seconds':time.monotonic()-t,'elapsed':elapsed()})
  except Exception as e:errors.append(str(e));event('harness-error',{'error':str(e),'traceback':traceback.format_exc()})
  (ROOT/'exercise-status.json').write_text(json.dumps({'cycles':i,'seconds':elapsed(),'errors':errors},indent=2))
 time.sleep(1)
(ROOT/'exercise-ended.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':elapsed(),'cycles':i,'errors':errors},indent=2));event('exercise-ended',{'seconds':elapsed(),'cycles':i,'errors':len(errors)})
