from manual import *
import zipfile
with manual():
 compare(C/'copy/left',C/'copy/right');pattern('*.txt');snapshot('10-filtered-copy-before');summary('copy-before')
 # Copy the visible directory: its hidden .bin must be retained.
 js('const r=[...document.querySelectorAll(".page:not([hidden]) .viewport .row")].find(e=>e.querySelector(".name")?.innerText.trim().endsWith("dir"));r.click()');click('Copy →');time.sleep(.25);desktop_key('Return');time.sleep(.4)
 event('ordinary-filtered-copy',{'txt':(C/'copy/right/dir/keep.txt').read_text(),'hidden':(C/'copy/right/dir/hidden.bin').read_text()});snapshot('11-filtered-dir-copy-after')
 # Same action on a visible archive container.
 js('const r=[...document.querySelectorAll(".page:not([hidden]) .viewport .row")].find(e=>e.querySelector(".name")?.innerText.includes("bundle.zip"));r.click()');click('Copy →');time.sleep(.25);desktop_key('Return');time.sleep(.4)
 with zipfile.ZipFile(C/'copy/right/bundle.zip')as z:contents={n:z.read(n).decode()for n in z.namelist()}
 event('archive-filtered-copy',contents);snapshot('12-filtered-archive-copy-after');summary('copy-after');close_active()
