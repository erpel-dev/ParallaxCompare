from manual import *
from PIL import ImageGrab
import zipfile
for side in ['left','right']:
 p=C/'archive-warning'/side/'bundle.zip';p.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(p,'w')as z:z.writestr('keep.txt',side+' VISIBLE\n');z.writestr('hidden.bin',side+' DO NOT REPLACE\n')
with manual():
 compare(C/'archive-warning/left',C/'archive-warning/right');pattern('*.txt');js('document.querySelector(".page:not([hidden]) .viewport .row").click()');click('Copy →');time.sleep(.3);ImageGrab.grab(xdisplay=':99').save(ROOT/'screenshots/15-archive-copy-warning-native.png');event('native-dialog-screenshot','15-archive-copy-warning-native.png');desktop_key('Return');time.sleep(.3)
 with zipfile.ZipFile(C/'archive-warning/right/bundle.zip')as z:event('archive-warning-result',{n:z.read(n).decode()for n in z.namelist()})
 snapshot('16-archive-warning-after');close_active()
