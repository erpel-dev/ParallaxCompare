from filter_ui import *
compare(C/'left',C/'right');settled();snapshot('01-baseline');summary('baseline')
patterns=['*.txt','*.TXT','?.txt','é.txt','?.TXT','ä.txt','[a-c].txt','file?.log','file[12].log','*.{java,kt}','*.java *.kt','*.java;*.kt','*.java,*.kt','src/*.rs','src/**/*.rs','**/*.rs','/src/**/*.rs','folder.rs','docs/','docs/**','report final.txt','report\\ final.txt','report,final.txt','report;final.txt','a[[]1].txt','missing*','[','*','']
for i,p in enumerate(patterns):
 try:
  st=pattern(p);event('pattern-case',{'input':p,**st})
  if p in ['?.txt','ä.txt','*.{java,kt}','src/**/*.rs','report final.txt','[','docs/']:snapshot(f'02-pattern-{i:02}')
 except Exception as e:event('harness-error',{'pattern':p,'error':str(e)})
pattern('*.txt');click('Flat');time.sleep(.3);summary('flat-txt');snapshot('03-flat-txt')
for label in ['Different','Same','Left only','Right only','All files']:
 click(label,prefix=True);time.sleep(.15);summary('txt-'+label)
click('Flat');pattern('');close_active();event('initial-round-complete',{'errors':js('return window.exploreErrors')})
