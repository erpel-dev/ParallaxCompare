from manual import *
with manual():
 for n in [100000,1000000]:
  compare(C/f'large/left-{n}.txt',C/f'large/right-{n}.txt');snapshot(f'40-large-{n}-start')
  for ratio in [1,.5,0,1]:
   t=time.monotonic();js('const e=document.querySelector(".page:not([hidden]) .viewport");e.scrollTop=(e.scrollHeight-e.clientHeight)*arguments[0];e.dispatchEvent(new Event("scroll"));',ratio);wait('return !document.querySelector(".page:not([hidden]) .row.loading")');time.sleep(.15)
   event('large-scroll',{'lines':n,'ratio':ratio,'seconds':time.monotonic()-t,'text':visible()[-2300:]})
  click('Find');control('.findbar input',f'line {n-1:07}');time.sleep(.5);event('large-search',{'lines':n,'text':visible()[-1800:]});snapshot(f'41-large-{n}-last-line')
  close_active()
 for n in [500,1000,2000,4000]:
  t=time.monotonic();merge(f'many{n}');event('many-conflicts-open',{'conflicts':n,'seconds':time.monotonic()-t});click('↓ Next conflict');click('← Take local');time.sleep(.15);snapshot(f'42-many-{n}');click('💾 Save result');time.sleep(.2);desktop_key('Escape');time.sleep(.1)
  # Undo back to pristine, then close without losing any real work.
  click('↶ Undo');time.sleep(.2);close_active();time.sleep(.2)
