import tkinter as tk,pathlib
r=tk.Tk();r.withdraw();r.clipboard_clear();r.clipboard_append('😀 line one\nline two\nline three');r.update();pathlib.Path('/workspace/hour-exploration-20261026/clipboard-ready').touch();r.after(60000,r.destroy);r.mainloop()
