from manual import *
with manual():
 for pause in [0,30,100,250]:
  merge('unicode');js('document.querySelector(".page:not([hidden]) .rrow:not(.header):not(.loading)").click()');wait('return !!document.querySelector(".page:not([hidden]) input.editor")')
  control('input.editor','before');js('const e=document.querySelector(".page:not([hidden]) input.editor");e.focus();e.setSelectionRange(6,6)')
  actions=[]
  for k in ['\ue007','A','B','C']:
   actions.extend([{'type':'keyDown','value':k},{'type':'keyUp','value':k}])
   if pause:actions.append({'type':'pause','duration':pause})
  request('POST',f'/session/{sid()}/actions',{'actions':[{'type':'key','id':'keyboard','actions':actions}]})
  time.sleep(.6);event('merge-enter-focus',{'pauseMs':pause,'focus':js('return {tag:document.activeElement.tagName,cls:document.activeElement.className,editor:!!document.querySelector(".page:not([hidden]) input.editor"),text:document.querySelector(".page:not([hidden]) .result")?.innerText}'),'text':visible()})
  click('💾 Save result');time.sleep(.15);actual=pathlib.Path(CASES['unicode']['output']).read_text();event('merge-enter-content',{'pauseMs':pause,'actual':actual,'expected':'before\nABC\nsecond\n'})
  if pause==250:snapshot('16-merge-enter-loses-focus')
  close_active()
 merge('empty');snapshot('17-empty-merge-fixed');js('document.querySelector(".page:not([hidden]) .empty-result").click()');wait('return !!document.querySelector(".page:not([hidden]) input.editor")');control('input.editor','new content');click('💾 Save result');time.sleep(.2);event('empty-merge-saved',{'actual':pathlib.Path(CASES['empty']['output']).read_text(),'text':visible()});snapshot('18-empty-merge-saved');close_active()
