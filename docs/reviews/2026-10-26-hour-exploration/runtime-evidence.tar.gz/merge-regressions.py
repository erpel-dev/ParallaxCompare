from manual import *
import subprocess,os,stat
M=json.loads((C/'regression-fixtures/fixtures.json').read_text())if(C/'regression-fixtures/fixtures.json').exists()else json.loads((C/'regression-fixtures/manifest.json').read_text())
with manual():
 # Mode preservation on real unmerged index stages.
 repo=C/'regression-fixtures/M02-M03-mode-conflicts';conflicts(repo);snapshot('50-mode-conflicts')
 for p in ['link','script.sh']:
  js('const row=[...document.querySelectorAll(".page:not([hidden]) tbody tr")].find(e=>e.querySelector(".file")?.innerText.trim()===arguments[0]);[...row.querySelectorAll("button")].find(e=>e.innerText==="Take remote").click()',p);time.sleep(.2)
 click('Stage 2 resolved files');time.sleep(.4);event('git-modes-regression',{'islink':(repo/'link').is_symlink(),'target':os.readlink(repo/'link'),'mode':oct(stat.S_IMODE((repo/'script.sh').stat().st_mode)),'index':subprocess.check_output(['git','-C',str(repo),'ls-files','-s'],text=True),'text':visible()});snapshot('51-modes-staged');close_active()
 # Correctly separated conflicts.
 for n in [500,1000,2000,4000]:
  a=M[f'M07-{n}-conflicts'];t=time.monotonic();merge('clean',**{k:a[k]for k in ['base','local','remote']},output=a['result']);event('separated-conflicts-open',{'expectedConflicts':n,'seconds':time.monotonic()-t,'label':visible()[:200]});snapshot(f'52-separate-{n}');close_active()
 # Empty results are editable after the recent fix.
 merge('empty');js('document.querySelector(".page:not([hidden]) .rrow.empty").click()');wait('return !!document.querySelector(".page:not([hidden]) input.editor")');control('input.editor','new content');click('💾 Save result');time.sleep(.25);event('empty-merge-regression',{'actual':pathlib.Path(CASES['empty']['output']).read_text(),'text':visible()});snapshot('53-empty-merge-fixed');close_active()
