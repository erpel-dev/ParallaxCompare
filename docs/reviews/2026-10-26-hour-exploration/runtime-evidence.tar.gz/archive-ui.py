from manual import *
import zipfile,os
A=C/'archive-ui';A.mkdir(exist_ok=True);(A/'reference.txt').write_text('OLD A\n')
for side,label in [('source','NEW'),('dest','OLD')]:
 d=A/side;d.mkdir(exist_ok=True)
 with zipfile.ZipFile(d/'target.zip','w',compression=zipfile.ZIP_STORED)as f:
  for p,t in [('a.txt',label+' A\n'),('b.txt',label+' B\n')]:f.writestr(zipfile.ZipInfo(p,(2020,1,1,0,0,0)),t)
 os.utime(d/'target.zip',(1700000000,1700000000))
with manual():
 compare(A/'reference.txt',str(A/'dest/target.zip')+'!/a.txt');key=js('return document.querySelector(".tab.on").dataset.key');snapshot('60-archive-old-entry')
 js('document.querySelectorAll(".page:not([hidden]) .viewport .row .code")[1].dispatchEvent(new MouseEvent("click",{bubbles:true}))');wait('return !!document.querySelector(".page:not([hidden]) input.edit")');control('input.edit','MY A');js('document.activeElement.blur()');time.sleep(.2)
 compare(A/'source',A/'dest');js('const e=[...document.querySelectorAll(".page:not([hidden]) .viewport .row")].find(e=>e.querySelector(".name")?.innerText.includes("target.zip"));e.click()');snapshot('61-archive-before-copy');click('Copy →');time.sleep(.4);desktop_key('Return');time.sleep(.6)
 with zipfile.ZipFile(A/'dest/target.zip')as f: event('archive-ui-after-copy',{n:f.read(n).decode()for n in f.namelist()})
 snapshot('62-archive-after-copy');js('document.querySelector(`.tab[data-key="${arguments[0]}"] .label`).click()',key);time.sleep(.3);snapshot('63-archive-stale-draft');combo('\ue009','s');time.sleep(.5)
 with zipfile.ZipFile(A/'dest/target.zip')as f:event('archive-ui-after-save',{n:f.read(n).decode()for n in f.namelist()})
 snapshot('64-archive-after-save');close_active()
