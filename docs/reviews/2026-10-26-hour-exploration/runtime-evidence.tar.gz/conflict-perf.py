from manual import *
import subprocess
R=C/'conflict-many';R.mkdir(exist_ok=True)
def git(*args,data=None):return subprocess.run(['git','-C',str(R),*args],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
if not(R/'.git').exists():git('init','-q','-b','main')
oids=[git('hash-object','-w','--stdin',data=(x+' value\n').encode()).decode().strip()for x in ['base','local','remote']]
records=''.join(f'100644 {oid} {s}\tfile{i:04}.txt\n'for i in range(120)for s,oid in enumerate(oids,1));git('update-index','--index-info',data=records.encode())
with manual():
 before=js('return window.exploreCalls.filter(x=>x.command==="structured_merge_conflict").length');t=time.monotonic();new();click('Resolve conflicts in a repository…');input('Repository',R);click('Show conflicts →');wait('return document.querySelectorAll(".page:not([hidden]) .conflicts tbody tr").length===120',120);event('conflict-list-performance',{'files':120,'uniqueStageBlobs':3,'seconds':time.monotonic()-t,'text':visible()[:700]});snapshot('77-120-repository-conflicts');time.sleep(.7);close_active();event('closed-conflicts-tab',{'completedBefore':before,'completedAtClose':js('return window.exploreCalls.filter(x=>x.command==="structured_merge_conflict").length'),'totalTabs':js('return document.querySelectorAll(".conflicts").length'),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});(ROOT/'closed-conflict-check.json').write_text(json.dumps({'before':before,'monotonic':time.monotonic()}))
