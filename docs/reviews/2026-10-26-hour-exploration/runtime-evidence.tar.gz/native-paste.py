from manual import *
B=C/'native-paste';B.mkdir(exist_ok=True)
for s in ['left','right']:(B/(s+'.txt')).write_text('alpha\nbeta\n')
with manual():
 compare(B/'left.txt',B/'right.txt');js('document.querySelectorAll(".page:not([hidden]) .viewport .row .code")[1].dispatchEvent(new MouseEvent("click",{bubbles:true}))');wait('return !!document.querySelector(".page:not([hidden]) input.edit")');js('const e=document.querySelector(".page:not([hidden]) input.edit");e.focus();e.setSelectionRange(0,e.value.length);window.nativePastes=[];document.addEventListener("paste",e=>window.nativePastes.push({trusted:e.isTrusted,text:e.clipboardData.getData("text/plain")}),{capture:true})');combo('\ue009','v');time.sleep(.5);combo('\ue009','s');time.sleep(.3);event('native-multiline-paste',{'actual':(B/'right.txt').read_text(),'expected':'😀 line one\nline two\nline three\nbeta\n','pasteEvents':js('return window.nativePastes'),'text':visible()[-1200:]});snapshot('87-native-multiline-paste');close_active()
