from ui import *
import traceback,fcntl
start=time.monotonic();stop=start+3600
(ROOT/'active-run.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic':start,'minimumActiveSeconds':3600,'note':'Earlier wall time includes an interaction pause and is excluded from this continuous exercise.'},indent=2))
i=0;failures=[]
while time.monotonic()<stop and not(ROOT/'stop-soak').exists():
 if (ROOT/'pause-soak').exists():
  (ROOT/'soak-paused').touch();time.sleep(.2);continue
 (ROOT/'soak-paused').unlink(missing_ok=True)
 with (ROOT/'gui.lock').open('w')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  if (ROOT/'pause-soak').exists():continue
  i+=1;t=time.monotonic();case=''
  try:
   if i%15==0:
    case='merge-clean';merge('clean');click('💾 Save result');time.sleep(.15)
    check('soak-clean-result',pathlib.Path(CASES['clean']['output']).read_text()=='ONE\ntwo\nthree\nfour\nFIVE\n')
   elif i%8==0:
    case='folder';compare(C/'left',C/'right');click('Different',prefix=True);click('Flat');time.sleep(.2);click('Left only',prefix=True);click('All files',prefix=True)
   elif i%5==0:
    case='yaml';compare(C/'left/typed.yaml',C/'right/typed.yaml');control('.toolbar > select','normalizedYaml');time.sleep(.15);click('All differences',prefix=True);check('soak-yaml-difference','OLD'in visible()and'NEW'in visible())
   else:
    case='text';compare(C/'left/changed.txt',C/'right/changed.txt');click('All differences',prefix=True);click('Same',prefix=True);click('All rows',prefix=True);click('Find');control('.findbar input','value');time.sleep(.25);keys('\ue00c');click('Next ▶')
   if i%20==0:snapshot(f'80-soak-{i:04}')
   close_active()
   event('soak-cycle',{'cycle':i,'case':case,'seconds':time.monotonic()-t,'activeElapsed':time.monotonic()-start,'jsErrors':js('return window.exploreErrors')})
  except Exception as e:
   err={'cycle':i,'case':case,'error':str(e),'traceback':traceback.format_exc()};failures.append(err);event('soak-harness-error',err)
   try:close_active()
   except:pass
  (ROOT/'soak-status.json').write_text(json.dumps({'cycles':i,'elapsed':time.monotonic()-start,'failures':failures[-10:],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
 time.sleep(2)
(ROOT/'soak-ended.json').write_text(json.dumps({'cycles':i,'elapsed':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'failures':failures},indent=2))
event('soak-ended',{'cycles':i,'seconds':time.monotonic()-start,'errors':len(failures)})
